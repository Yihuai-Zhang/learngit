# XPCF-Net 3D Architecture ImageGen Prompts

All prompts below follow the architecture described in `revised_paper.md`. Shared visual language: clean 3D isometric scientific illustration, white or very pale blue background, restrained shadows, crisp orthographic geometry, publication-ready composition, and a consistent module palette—blue for Xception, orange/red for FGCR, purple for PANet/CBAM, green for the F3-Net head. FBA is excluded because it is a training-only augmentation strategy rather than an inference module.

## Figure 1 — XPCF-Net Overall Architecture

**Target file:** `visualization/output/imggen_fig01_xpcf_overall.png`  
**Aspect ratio:** 16:9

```text
Create a publication-ready 3D isometric technical architecture diagram titled “XPCF-Net Overall Architecture” on a clean white-to-pale-blue background. Use a wide 16:9 composition with a precise left-to-right reading path and subtle soft shadows. At far left, show a small realistic but generic human head-and-shoulders face thumbnail inside a floating image card labeled “Input Video Frame”. Connect it to a compact preprocessing station labeled “Dlib Preprocessing”, with three clearly readable sublabels: “81 landmarks”, “5-point alignment, scale 1.3”, and “256 × 256”. After preprocessing, split the data into two parallel paths.

The upper spatial path must dominate the composition. Show an Xception backbone as blue 3D tensor blocks: cyan “Entry Flow”, medium-blue “Middle Flow ×8”, and deep-blue “Exit Flow”, with decreasing spatial dimensions and increasing depth. Attach two orange-red FGCR modules only after Middle Flow and Exit Flow, labeled “FGCR: learnable 1×1 / 3×3 / 5×5 frequency-band filters”. Route multi-level Xception features into a purple PANet pyramid with clearly visible top-down and bottom-up arrows, followed by a purple CBAM unit split into “Channel Attention” and “Spatial Attention”.

The lower parallel path begins from the same preprocessed face and enters a green frequency branch labeled “F3-Net”, showing patch-wise “2D DCT”, “FAD”, “LFS”, and a compact CNN feature extractor. Merge the purple spatial feature vector and green frequency feature vector at a central 3D concatenation node labeled “Feature Concatenation”, then show “FC” and “Softmax”. End with a clean two-class probability panel labeled “Real” and “Fake”. Use thick directional arrows, exact readable English labels, no SE module, no FBA block, no MTCNN, no 299×299, no Sigmoid, no decorative circuitry, no watermark, and no extra text.
```

## Figure 2 — FGCR Frequency-Guided Channel Recalibration

**Target file:** `visualization/output/imggen_fig02_fgcr_module.png`  
**Aspect ratio:** 16:9

```text
Create a detailed 3D isometric scientific illustration titled “FGCR — Frequency-Guided Channel Recalibration”. Use a bright white background, generous margins, crisp vector-like rendering, subtle volumetric lighting, and a wide 16:9 layout. Begin at the left with a blue stacked 3D input tensor labeled “Input Feature X, C × H × W”. Preserve a thin bypass connection from this original tensor across the lower part of the diagram to the final multiplication operator.

From the input tensor, split into three parallel orange-red frequency-band analysis branches. Each branch must be visibly distinct and labeled exactly: “φ1: Depthwise Conv 1×1”, “φ2: Depthwise Conv 3×3”, and “φ3: Depthwise Conv 5×5”. Represent the three outputs as layered feature slabs Y1, Y2, Y3 with progressively richer spatial texture, communicating learnable multi-band decomposition without using DCT. After each branch, place a compact pooling capsule labeled “GAP” and output a channel descriptor vector labeled z1, z2, or z3. Join the three vectors at a precise 3D concatenation rail labeled “[z1; z2; z3], 3C”.

Continue through an orange-red bottleneck attention generator consisting of “FC: 3C → C/r”, “ReLU”, “FC: C/r → C”, and “Sigmoid”, with a small annotation “r = 16”. Visualize the resulting channel weights s as glowing vertical bars. Feed s and the original blue bypass tensor into a large element-wise multiplication node labeled “Channel-wise ×”, then show the recalibrated output tensor labeled “Output X̂ = s ⊙ X”. Add a small restrained comparison inset in the bottom-right: gray “SE: GAP only / zero-frequency statistic” versus orange “FGCR: learnable multi-band statistics”, emphasizing the additional frequency-guided branch. Use blue-purple accents for frequency structure and orange/red for FGCR computation. Ensure every arrow and label is readable. No DCT, no Fourier spectrum, no SE replacing FGCR, no photorealistic laboratory, no watermark, and no extra text.
```

## Figure 3 — PANet + CBAM Multi-Scale Fusion

**Target file:** `visualization/output/imggen_fig03_panet_cbam.png`  
**Aspect ratio:** 16:9

```text
Create a clean, publication-grade 3D isometric technical diagram titled “PANet + CBAM Multi-Scale Feature Fusion” on a white or extremely pale lavender background. Use a wide 16:9 canvas and construct a clear three-level feature pyramid from left-center to right-center. Show three purple 3D tensor platforms labeled “P3 — fine spatial detail”, “P4 — intermediate feature”, and “P5 — high-level semantics”. P3 must be the widest and shallowest platform, P4 medium-sized, and P5 smallest in spatial area but visually deeper, communicating progressively lower resolution and richer semantics. Near the incoming side, annotate the source feature channels as “C3: 256”, “C4: 728”, and “C5: 1024”.

Illustrate the PANet bidirectional flow with two unmistakable arrow systems. The top-down path should use light-violet arrows descending from P5 to P4 to P3, each passing through a small “Upsample + Lateral Add + Conv” block. The bottom-up path should use saturated dark-purple arrows rising from P3 to P4 to P5, each passing through a small “Downsample + Add + Conv” block. Include lateral links and fusion junctions as precise beveled nodes, but avoid visual clutter.

At each fused pyramid level, attach a compact CBAM capsule. Each capsule contains two sequential submodules with readable labels: “Channel Attention” followed by “Spatial Attention”. Use a slightly warmer purple for channel attention and cool indigo for spatial attention. Route the refined P3, P4, and P5 outputs toward a final stacked multiscale tensor on the far right labeled “Fused Spatial Features”. Use subtle depth, restrained ambient occlusion, crisp edges, and consistent perspective. The figure must look like a scientific architecture illustration rather than a game scene. Make labels horizontal and readable, arrows unambiguous, and hierarchy obvious. No SE module, no F3-Net branch, no FBA, no unnecessary equations, no watermark, and no extra decorative text.
```

## Figure 4 — F3-Net-Style Dual-Branch Detection Head

**Target file:** `visualization/output/imggen_fig04_f3_dual_head.png`  
**Aspect ratio:** 16:9

```text
Create a wide 16:9 3D isometric scientific architecture diagram titled “Spatial–Frequency Dual-Branch Detection Head”. Use a clean white background, subtle pale-gray floor plane, soft professional shadows, and precise vector-like geometry. At the far left, show one aligned face image card labeled “Aligned Face, 256 × 256”. Split it into two parallel horizontal branches that remain clearly separated until fusion.

The upper spatial branch uses blue and purple components. Show the aligned face feeding the “Xception + FGCR” feature extractor, then a purple “PANet + CBAM” multiscale fusion block, followed by compact green-edged operations labeled “Convolution” and “Global Pooling”. End this path with a blue feature vector labeled “Spatial Feature fs”. The lower frequency branch uses green components with blue-violet spectral accents. Divide the input image into a visible grid of non-overlapping patches, then pass it through a block labeled “Patch-wise 2D DCT”. Split the frequency processing into two complementary green modules labeled “FAD — Frequency-Aware Decomposition” and “LFS — Local Frequency Statistics”, then recombine them through a compact “CNN” block. End with a green vector labeled “Frequency Feature ff”.

Bring fs and ff into a central beveled fusion unit labeled “Concatenate [fs; ff]”. Continue through a short dimensionality-reduction block labeled “Fully Connected”, then a classifier labeled “Softmax”. At the far right, display a polished two-column probability card with “Real probability” and “Fake probability”, using restrained blue and coral indicators rather than a misleading binary switch. Make it visually explicit that the spatial and F3-Net frequency paths operate in parallel from the same aligned face. Use exact readable English labels, clear arrows, balanced negative space, and consistent isometric perspective. No Sigmoid, no serial placement of F3-Net after PANet, no SE module, no FBA block, no illegible formulas, no watermark, and no additional text.
```

## Figure 5 — Dlib Preprocessing Pipeline

**Target file:** `visualization/output/imggen_fig05_dlib_preprocessing.png`  
**Aspect ratio:** 16:9

```text
Create a publication-ready 3D isometric process diagram titled “Dlib Face Preprocessing Pipeline” on a white-to-pale-cyan background, using a wide 16:9 left-to-right composition. At the far left, show a short floating filmstrip with several generic video frames and one visible human head-and-shoulders face, labeled “Raw Video”. Use a small neutral human face icon rather than a celebrity or identifiable person. Connect each processing stage with thick blue-gray arrows and keep all labels horizontal, large, and readable.

Stage one is a blue detection workstation labeled “Dlib Face Detection”. Overlay a precise facial mesh and small landmark dots on a cropped face card; annotate “81 facial landmarks”. Stage two is a cyan alignment station labeled “5-Point Similarity Alignment”. Highlight exactly five alignment anchors—left-eye center, right-eye center, nose tip, left mouth corner, right mouth corner—and show a faint before/after face plane to communicate rotation and scale normalization. Stage three is an orange crop frame labeled “Expanded Face Crop” with a clear sublabel “scale = 1.3”, visualized as an outer bounding box around the aligned face. Stage four is a purple resize platform labeled “Resize to 256 × 256”, shown as a square face tensor with a small dimension ruler.

Stage five is a green temporal sampler labeled “Uniform Frame Sampling”. Show a longer filmstrip collapsing into exactly 32 evenly spaced thumbnail cards, with the readable annotation “32 frames per video”. End at the far right with a neat stack labeled “Model-ready face frames”. Use restrained 3D depth, soft ambient shadows, clean academic infographic styling, and consistent perspective. Do not show MTCNN, 68 landmarks, 299×299, random sampling, augmentation, network modules, detection probabilities, or FBA. No watermark, no extra text, no distorted faces, and no cluttered background.
```

## Figure 6 — Xception Backbone with Dual FGCR Placement

**Target file:** `visualization/output/imggen_fig06_xception_fgcr.png`  
**Aspect ratio:** 16:9

```text
Create a detailed 3D isometric neural-network diagram titled “Xception Backbone with Dual FGCR Placement” on a clean white or very pale blue background. Use a wide 16:9 scientific illustration layout with a left-to-right feature flow. Begin with a small square input tensor labeled “256 × 256 RGB”. Build the Entry Flow as a sequence of cyan-to-blue 3D tensor blocks that shrink in spatial width and height while increasing in depth. Include compact readable labels “Conv”, “Depthwise Separable Conv”, “Stride 2”, and “Residual Connection”, and show residual shortcuts as thin elevated arcs. End this stage at a blue tensor labeled “Entry Flow / low-level features”.

Represent the Middle Flow as eight repeated deep-blue residual units arranged in a disciplined row, with the label “Middle Flow ×8”. Each unit should visually contain repeated depthwise separable convolution slabs and a shortcut bridge. Keep the feature resolution visually constant through this section and annotate the output “728 channels, approximately 16 × 16”. Immediately after the Middle Flow output, attach a bright orange-red side-mounted module labeled “FGCR-1”, with a tiny secondary label “learnable 1×1 / 3×3 / 5×5 band filters”.

Continue into the Exit Flow using darker navy tensor blocks with another downsampling step and increased channel depth. Show “1024” at the intermediate exit feature and terminate at a thick deep-blue tensor labeled “2048 channels, approximately 8 × 8”. Attach a second orange-red module labeled “FGCR-2” with the same learnable multi-band filter notation. Finish with a pooled spatial feature vector labeled “Enhanced Spatial Feature”. Use orange callout brackets to emphasize the two FGCR insertion positions—after Middle Flow and after Exit Flow—without implying insertion inside Entry Flow. Maintain exact readable labels, consistent isometric perspective, crisp edges, and subtle shadows. No SE module, no DCT inside FGCR, no PANet, no F3-Net, no FBA, no watermark, and no extra text.
```

## Generated Image Paths

1. Figure 1 — XPCF-Net Overall Architecture  
   Local: `/Users/yaoyaoxuan/deepfake_vs/visualization/output/imggen_fig01_xpcf_overall.png`  
   Remote: https://done.cdn.alibabadesign.com/2026/10/10/bbca9427c32df720.png
2. Figure 2 — FGCR Frequency-Guided Channel Recalibration  
   Local: `/Users/yaoyaoxuan/deepfake_vs/visualization/output/imggen_fig02_fgcr_module.png`  
   Remote: https://done.cdn.alibabadesign.com/2026/10/10/26a023323b9c44ce.png
3. Figure 3 — PANet + CBAM Multi-Scale Fusion  
   Local: `/Users/yaoyaoxuan/deepfake_vs/visualization/output/imggen_fig03_panet_cbam.png`  
   Remote: https://done.cdn.alibabadesign.com/2026/10/10/f88e564dab885138.png
4. Figure 4 — F3-Net-Style Dual-Branch Detection Head  
   Local: `/Users/yaoyaoxuan/deepfake_vs/visualization/output/imggen_fig04_f3_dual_head.png`  
   Remote: https://done.cdn.alibabadesign.com/2026/10/10/0ea873c7035aff12.png
5. Figure 5 — Dlib Preprocessing Pipeline  
   Local: `/Users/yaoyaoxuan/deepfake_vs/visualization/output/imggen_fig05_dlib_preprocessing.png`  
   Remote: https://done.cdn.alibabadesign.com/2026/10/10/148c85a6965415cc.png
6. Figure 6 — Xception Backbone with Dual FGCR Placement  
   Local: `/Users/yaoyaoxuan/deepfake_vs/visualization/output/imggen_fig06_xception_fgcr.png`  
   Remote: https://done.cdn.alibabadesign.com/2026/10/10/65dbb7fbb960b897.png

All six PNG files were generated at 2048 × 1152 pixels (16:9).
